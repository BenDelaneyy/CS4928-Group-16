OPEN THIS FILE WITH TEXT EDITOR TO SEE IT CORRECTLY

The fodler it is structred as follow: 

- v1: contatins the first 30.000 projects analyzed
	|
	|__ output
		|
		|__ n_microservices_per_projects.csv: 	contains the 													information
										  		regarding the whole dataset analyzed
	    |
	    |__ filtered: 	contains information about only those projects 
	   					having 
					 	more than equal 2 number of microservices
				|
				|__ n_microservices_per_projects.csv: information on the 
													  projects
				|
				|__ projects: folder with the .json files
	    

- v2: contains all the projects analyzed
	|
	|__ output
		|
		|__ not_filtered: contains all the projects analyzed:
				|
				|__ n_microservices_per_projects.csv: 	contains the 											information
												  		regarding the whole dataset analyzed
				|
				|__ projects: folder with the .json files
	    |
	    |__ filtered: 	contains information about only those projects 
	   					having 
					 	more than equal 2 number of microservices
				|
				|__ n_microservices_per_projects.csv: information on the 
													  projects
				|
				|__ projects: folder with the .json files

